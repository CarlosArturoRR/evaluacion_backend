<?php>
  $busca_Ciudad = $_POST['$busca_Ciudad'];
  $busca_Tipo = $_POST['busca_Tipo'];
  $rango_precios = $_POST['$rango_precios'];
  echo "Ciudad: ".$busca_Ciudad." Tipo: ".$busca_Tipo." Rango: ".$rango_precios
?>
